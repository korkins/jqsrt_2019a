#include <stdio.h>  /* printf, fprintf */
#include <time.h>   /* clock */
#include <iostream> /* system("pause") */
#define PI 3.1415926535897932
#define TWOPI 6.2831853071795864
//
void gauszw(double, double, int, double *, double *);
void rayxk(double const, double *, double *, double *);
void domm0(int const, int const,
           double const *, double const *,
           double const *, double const *, int const,
           double const *, int const,
           double const *, int const,
           double const *, int const,
           double *);
void read2d(char *, int, int, double **);
//
int main()
{
	int ik, ilr, irun, isrf, ng1, nk, nlr, nmu, nmu0, nrun, ig, nxk;
	double depf, ssa05, time_start, time_end;
	double *mu, *mu0, *tau, *ssa, *x11k, *x22k, *x33k, *x12k, *iqu, *mug, *wg, **xk_txt;
	double r11k[3], r22k[3], r12k[3];
//
	nrun = 1000;
	time_start = (double)clock() /(double)CLOCKS_PER_SEC;
	for (irun = 0; irun < nrun; irun++) {
		printf("\n");
		printf("irun = %i\n", irun+1);
//
//		RAYLEIGH TEST:
//
		ng1 = 8;
		nxk = 3; // rayleigh
		nmu0 = 1;
		nlr = 1;
		nk = nxk;
//	
		mu0 = new double[nmu0];
		tau = new double[nlr];
		ssa = new double[nlr];
		x11k = new double[nk*nlr];
		x22k = new double[nk*nlr];
		x33k = new double[nk*nlr];
		x12k = new double[nk*nlr];
		iqu = new double[ng1*6];
//
//		-- not used at the moment > --
		isrf = 0;
		nmu = 1;
		mu = new double [nmu];
		mu[0] = -1.0;
//		-- < not used at the moment --
//
		mu0[0] = 1.0;
		tau[0] = 0.5;
		ssa[0] = 0.99999999;
		depf = 0.0;
		rayxk(depf, r11k, r22k, r12k);
		for (ilr = 0; ilr < nlr; ilr++) {
			ssa05=0.5*ssa[ilr];
			for (ik = 0; ik < nk; ik++) {
				x11k[ilr*nk+ik] = ssa05*r11k[ik];
				x22k[ilr*nk+ik] = ssa05*r22k[ik];
				x33k[ilr*nk+ik] = 0.0;
				x12k[ilr*nk+ik] = ssa05*r12k[ik];
			} // for ik
		} // for ilr
//
		printf("\n");
		printf(" Rayleigh test: ng1=%i, nk=%i\n", ng1, nk);
		domm0(isrf, ng1, x11k, x22k, x33k, x12k, nk, tau, nlr, mu, nmu, mu0, nmu0, iqu);

		if (irun+1 == nrun) {
			mug = new double[ng1];
			wg = new double[ng1];
			gauszw(0.0, 1.0, ng1, mug, wg);
			printf("\n");
			printf("  mug:        I:               Q:\n");
			for (ig = 0; ig < ng1; ig++) printf("%8.4f %16.5e %16.5e\n", -mug[ig], iqu[3*ig]/TWOPI, iqu[3*ig+1]/TWOPI);
			for (ig = 0; ig < ng1; ig++) printf("%8.4f %16.5e %16.5e\n",  mug[ig], iqu[3*(ng1+ig)]/TWOPI, iqu[3*(ng1+ig)+1]/TWOPI);
			delete[] mug;
			delete[] wg;
		} // if irun
//
		delete[] x11k;
		delete[] x22k;
		delete[] x33k;
		delete[] x12k;
//==============================================================================================================================
//
//		AEROSOL TEST:
//
//		moments from txt file
		nxk = 36; 
		xk_txt = new double *[nxk];
		for (ik = 0; ik < nxk; ik++)
			xk_txt[ik] = new double[7]; // k, a1k, a2k, a3k, a4k, b1k, b2k
		read2d("Xk0036_0695.txt", nxk, 7, xk_txt);
//
		nk = ng1*2+1;
//
		x11k = new double[nk*nlr];
		x22k = new double[nk*nlr];
		x33k = new double[nk*nlr];
		x12k = new double[nk*nlr];
//
		mu0[0] = 0.6;
		tau[0] = 1.0;
		ssa[0] = 0.95;
		for (ilr = 0; ilr < nlr; ilr++) {
			ssa05=0.5*ssa[ilr];
			for (ik = 0; ik < nk; ik++) {
				x11k[ilr*nk+ik] = ssa05*xk_txt[ik][1];
				x22k[ilr*nk+ik] = ssa05*xk_txt[ik][2];
				x33k[ilr*nk+ik] = ssa05*xk_txt[ik][3];
				x12k[ilr*nk+ik] = ssa05*xk_txt[ik][5];
			} // for ik
		} // for ilr
//
		printf("\n");
		printf(" Aerosol test: ng1=%i, nk=%i\n", ng1, nk);
		domm0(isrf, ng1, x11k, x22k, x33k, x12k, nk, tau, nlr, mu, nmu, mu0, nmu0, iqu);

		if (irun+1 == nrun) {
			mug = new double[ng1];
			wg = new double[ng1];
			gauszw(0.0, 1.0, ng1, mug, wg);
			printf("\n");
			printf("  mug:        I:               Q:\n");
			for (ig = 0; ig < ng1; ig++) printf("%8.4f %16.5e %16.5e\n", -mug[ig], iqu[3*ig]/TWOPI, iqu[3*ig+1]/TWOPI);
			for (ig = 0; ig < ng1; ig++) printf("%8.4f %16.5e %16.5e\n",  mug[ig], iqu[3*(ng1+ig)]/TWOPI, iqu[3*(ng1+ig)+1]/TWOPI);
			delete[] mug;
			delete[] wg;
		} // if irun
//
		delete[] mu0;
		delete[] tau;
		delete[] ssa;
		delete[] x11k;
		delete[] x22k;
		delete[] x33k;
		delete[] x12k;
		delete[] iqu;
		delete[] mu;
//
		for (ik = 0; ik<nxk; ik++) delete[] xk_txt[ik];
		delete[] xk_txt;
//
	}
	time_end = (double)clock() /(double)CLOCKS_PER_SEC;
	printf("\n");
	printf("cpu total time %fs\n", time_end - time_start);
	printf("Done!\n");
	system("pause");
	return 0;
}
/*------------------------------------------------------------------------------
19/01/01 - First created
------------------------------------------------------------------------------*/