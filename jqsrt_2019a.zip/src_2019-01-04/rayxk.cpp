# define SQRT62 1.2247448713915890 // sqrt(6)/2
//
void rayxk(double const depf, double *r11k, double *r22k, double *r12k) {
/*------------------------------------------------------------------------------
PURPOSE:
	To compute expansion coefficients for Rayleigh scattering.
IN:
	depf   d[1]   depolarization factor, depf ~= [0...6/7]
OUT:
	rijk   d[3]   moments: a1k=r11k, a2k=r22k, b1k=r12k

COMMENTS:
	r33k = 0.0; r44k & r34k are ignored in this subroutine (generate V).
	Following [1, p.43, Eq.(2.111)]: 0 <= depf <= 6/7
REFERENCESS:
	1.Hovenier JW et al., 2004: Transfer of Polarized Light in Planetary
	Atmosphere. Basic Concepts and Practical Methods, Dordrecht: Kluwer
	Academic Publishers.
PROTOTYPE:
	void rayxk(double const, double *, double *, double *);
------------------------------------------------------------------------------*/
//
	double df;
//------------------------------------------------------------------------------
//
//	[1, p.56]: 2.9 Expansion coefficients for Rayleigh scattering
	df = (1.0 - depf)/(1.0 + 0.5*depf);
	r11k[0] = 1.0; r11k[1] = 0.0; r11k[2] = 0.5*df;
	r22k[0] = 0.0; r22k[1] = 0.0; r22k[2] = 3.0*df;
	r12k[0] = 0.0; r12k[1] = 0.0; r12k[2] = SQRT62*df;
//
} // void rayxk(...)
/*------------------------------------------------------------------------------
 18/05/27 - First created and tested as part of ipol_cpp
*/