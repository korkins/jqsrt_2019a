#include <math.h>                               /* sqrt */
#include <iostream>                             /* printf */
#include <gsl/gsl_blas.h>                       /* dgemm, dgemv */
#include <gsl/gsl_eigen.h>                      /* eigen-problem */
#include <gsl/gsl_linalg.h>                     /* LU-decomposition */
#define C22 0.61237243569579452454932101867647  /* 1.5/sqrt(6) for Q22(x) */
#define TINY 1.0e-8                             /* to compare doubles */ 
//
void gauszw(double, double, int, double *, double *);
//
void domm0(int const isrf, int const ng1,
           double const *x11k, double const *x22k,
           double const *x33k, double const *x12k, int const nk,
           double const *tau, int const nlr,
           double const *mu, int const nmu,
           double const *mu0, int const nmu0,
           double *iqu) {
/*------------------------------------------------------------------------------
PURPOSE:
	To solve RT for m=0.
	*** THIS IS A LEARN-AND-TEST SUBROUTINE ***
IN:
	isrf   i           index for surface model
	ng1    i           number of Gauss nodes per hemisphere
	x..k   d[nlr*nk]   expansion_coefficients*ssa/2; ik->ilr; 2k+1 included
	nk     i           number of coefficients, min(nk)=3, MUST be odd: 3, 5, ... 115...
	tau    d[nlr]      total optical thickness of layers, from TOA to BOA
	nlr    i           number of layers in atmopshere
	mu     d[nmu]      cosines of view zeniths, mu > 0 - down to Aeronet
	nmu    i           length of mu
	mu0    d[nmu0]     cosines of solar zeniths, mu0 > 0
	nmu0   i           length of mu0
OUT:
	iqu    d[3*nmu*nmu0]   components of the Stokes vector; iqu->imu->imu0

COMMENTS:
	Order of indices, e.g. ik->ilr, means ik runs first (fastest)

	TRYME: remove if (ig == jg) ... else ... and process diag elements in
	(alf +/- bet) separately.

REFERENCES:
	1. HovenierJW et al. Transfer of polarized light, Kluwer 2004
	3. Stamnes K & Swanson RA, 1981: J.Atm.Sci 38, 387

PROTOTYPE:
	void domm0(int const, int const,
               double const *, double const *,
               double const *, double const *, int const,
               double const *, int const,
               double const *, int const,
               double const *, int const,
               double *);
------------------------------------------------------------------------------*/
//
	int
		ig, ik, ilr, jg, ng3, ng6, imu0, gsl_s;
	double
		difx11, difx12, difx13, difx21, difx22, difx23, difx31, difx32, difx33,
		sumx11, sumx12, sumx13, sumx21, sumx22, sumx23, sumx31, sumx32, sumx33,
		imui, mui, muj, qi, qi_1, qi_2, qj, qj_1, qj_2,
		ri, ri_1, ri_2, rj, rj_1, rj_2, evali, wj, taue, eti, e0, eb, neg, pos,
		q0, q0_1, q0_2, qn, qn_1, qn_2, qp, qp_1, qp_2,
		rn, rn_1, rn_2, rp, rp_1, rp_2, mun, mup, cs0, taui, den;
//
	double
		*cq_1, *cq_2, *cr_1, *cr_2, *mug, *wg, *apb, *amb, *ab, *umu, *abu, *u1, *u2,
		*eval, *eu1, *eu2, *fn, *fp, *f1, *f2, *A, *b, *x;
//------------------------------------------------------------------------------
//
	ng3 = ng1*3;
	ng6 = ng1*6;
//
	apb = new double[ng3*ng3];
	amb = new double[ng3*ng3];
	ab = new double[ng3*ng3];
	umu = new double[ng3];
	abu = new double[ng3];
	u1 = new double[ng3*ng3];
	u2 = new double[ng3*ng3];
	eu1 = new double[ng3*ng3];
	eu2 = new double[ng3*ng3];
	eval = new double[ng3];
	fn = new double[ng3];
	fp = new double[ng3];
	f1 = new double[ng3];
	f2 = new double[ng3];
//
	x = new double[ng6];
	b = new double[ng6];
	A = new double[ng6*ng6];
//
	mug = new double[ng1];
	wg = new double[ng1];
	gauszw(0.0, 1.0, ng1, mug, wg);
//
//	recurrence relation coefficients for Pk(x)=Qk0(x) & Rk0(x)=P20(x)=-Qk2(x)
	cq_1 = new double[nk];
	cq_2 = new double[nk];
	cr_1 = new double[nk];
	cr_2 = new double[nk];
	for (ik = 3; ik < nk; ik++) {
		cq_1[ik] = 2.0 - 1.0/ik;
		cq_2[ik] = 1.0 - 1.0/ik;
		cr_1[ik] = (2.0*ik - 1.0)/sqrt(1.0*ik*ik - 4.0);
		cr_2[ik] = sqrt( (ik + 1.0)*(ik - 3.0)/(1.0*ik*ik - 4.0) );
	} // ik
//
	taue = 0.0; // embedding of the top boundary: redefined at the end of the ilr-loop
	for (ilr = 0; ilr < nlr; ilr++) {
		taui = tau[ilr];
		for (jg = 0; jg < ng1; jg++) {		
			muj = mug[jg];
			wj = wg[jg];
//			columns for [3jg]
			for (ig = 0; ig<ng1; ig++) {
				mui = mug[ig];
				imui = 1.0/mug[ig];
				qi_2 = mui; qi_1 = 1.5*mui*mui - 0.5;
				qj_2 = muj; qj_1 = 1.5*muj*muj - 0.5;
				ri_2 = 0.0; ri_1 = C22*(1.0 - mui*mui); // Qk2(x)=3/(2*sqrt(6))*(1-x2)
				sumx11 = x11k[ilr*nk] + qj_1*x11k[ilr*nk+2]*qi_1;
				sumx12 = -qj_1*x12k[ilr*nk+2]*ri_1;
				sumx13 = 0.0;
				difx11 = muj*x11k[ilr*nk+1]*mui;
				difx12 = 0.0;
				difx13 = 0.0;
				for (ik = 3; ik < nk; ik += 2) {
//					current k=ik=3,5,7...: recurrence
					qi = cq_1[ik]*mui*qi_1 - cq_2[ik]*qi_2;
					qj = cq_1[ik]*muj*qj_1 - cq_2[ik]*qj_2;
					ri = cr_1[ik]*mui*ri_1 - cr_2[ik]*ri_2;
//					x1-x2: k=ik=3,5,7...only					NOTE: scaling factor 2.0 is omitted here on purpose
					difx11 += qj*x11k[ilr*nk+ik]*qi;
					difx12 += -qj*x12k[ilr*nk+ik]*ri;
//					for next k=ik+1:
					qi_2 = qi_1; qi_1 = qi;
					qj_2 = qj_1; qj_1 = qj;
					ri_2 = ri_1; ri_1 = ri;
//					next k=ik+1=4,6,8... -> next recurrence step
					qi = cq_1[ik+1]*mui*qi_1 - cq_2[ik+1]*qi_2;
					qj = cq_1[ik+1]*muj*qj_1 - cq_2[ik+1]*qj_2;
					ri = cr_1[ik+1]*mui*ri_1 - cr_2[ik+1]*ri_2;
//					x1+x2: k=ik+1=4,6,8...only					NOTE: again, scaling factor 2.0 is omitted here on purpose
					sumx11 += qj*x11k[ilr*nk+ik+1]*qi;
					sumx12 += -qj*x12k[ilr*nk+ik+1]*ri;
//					for next k=ik:
					qi_2 = qi_1; qi_1 = qi;
					qj_2 = qj_1; qj_1 = qj;
					ri_2 = ri_1; ri_1 = ri;
				} // for ik
				if (ig == jg) apb[3*jg*ng3+3*ig] = imui*(0.5 - difx11*wj); // (1 - 2xw)=2(0.5-xw) - see NOTE above
				else apb[3*jg*ng3+3*ig] = -imui*difx11*wj;
				apb[3*jg*ng3+3*ig+1] = -imui*difx12*wj;
				apb[3*jg*ng3+3*ig+2] = -imui*difx13*wj;
				if (jg == ig) amb[3*jg*ng3+3*ig] = imui*(0.5 - sumx11*wj);
				else amb[3*jg*ng3+3*ig] = -imui*sumx11*wj;
				amb[3*jg*ng3+3*ig+1] = -imui*sumx12*wj;
				amb[3*jg*ng3+3*ig+2] = -imui*sumx13*wj;
			} // for jg - columns in b[i,j]
//			columns for [3*jg+1]
			for (ig = 0; ig<ng1; ig++) {
				mui = mug[ig];
				imui = 1.0/mug[ig];
				qi_2 = mui; qi_1 = 1.5*mui*mui - 0.5;
				ri_2 = 0.0; ri_1 = C22*(1.0 - mui*mui);
				rj_2 = 0.0; rj_1 = C22*(1.0 - muj*muj);
				sumx21 = -rj_1*x12k[ilr*nk+2]*qi_1;
				sumx22 = rj_1*x22k[ilr*nk+2]*ri_1;
				sumx23 = 0.0;
				difx21 = 0.0;
				difx22 = 0.0;
				difx23 = 0.0;
				for (ik = 3; ik < nk; ik += 2) {
					qi = cq_1[ik]*mui*qi_1 - cq_2[ik]*qi_2;
					ri = cr_1[ik]*mui*ri_1 - cr_2[ik]*ri_2;
					rj = cr_1[ik]*muj*rj_1 - cr_2[ik]*rj_2;
					difx21 += -rj*x12k[ilr*nk+ik]*qi;
					difx22 += rj*x22k[ilr*nk+ik]*ri;
					qi_2 = qi_1; qi_1 = qi;
					ri_2 = ri_1; ri_1 = ri;
					rj_2 = rj_1; rj_1 = rj;
					qi = cq_1[ik+1]*mui*qi_1 - cq_2[ik+1]*qi_2;
					ri = cr_1[ik+1]*mui*ri_1 - cr_2[ik+1]*ri_2;
					rj = cr_1[ik+1]*muj*rj_1 - cr_2[ik+1]*rj_2;
					sumx21 += -rj*x12k[ilr*nk+ik+1]*qi;
					sumx22 += rj*x22k[ilr*nk+ik+1]*ri;
					qi_2 = qi_1; qi_1 = qi;
					ri_2 = ri_1; ri_1 = ri;
					rj_2 = rj_1; rj_1 = rj;
				} // for ik
				apb[(3*jg+1)*ng3+3*ig] = -imui*difx21*wj;
				if (ig == jg) apb[(3*jg+1)*ng3+3*ig+1] = imui*(0.5 - difx22*wj);
				else apb[(3*jg+1)*ng3+3*ig+1] = -imui*difx22*wj;
				apb[(3*jg+1)*ng3+3*ig+2] = -imui*difx23*wj;
				amb[(3*jg+1)*ng3+3*ig] = -imui*sumx21*wj;
				if (ig == jg) amb[(3*jg+1)*ng3+3*ig+1] = imui*(0.5 - sumx22*wj);
				else amb[(3*jg+1)*ng3+3*ig+1] = -imui*sumx22*wj;
				amb[(3*jg+1)*ng3+3*ig+2] = -imui*sumx23*wj;
			} // for jg - columns in b[i,j]
//			columns for [3*jg+2]
			for (ig = 0; ig<ng1; ig++) {
				mui = mug[ig];
				imui = 1.0/mug[ig];
				ri_2 = 0.0; ri_1 = C22*(1.0 - mui*mui);
				rj_2 = 0.0; rj_1 = C22*(1.0 - muj*muj);
				sumx31 = 0.0;
				sumx32 = 0.0;
				sumx33 = ri_1*x33k[ilr*nk+2]*rj_1;
				difx31 = 0.0;
				difx32 = 0.0;
				difx33 = 0.0;
				for (ik = 3; ik < nk; ik += 2) {
					ri = cr_1[ik]*mui*ri_1 - cr_2[ik]*ri_2;
					rj = cr_1[ik]*muj*rj_1 - cr_2[ik]*rj_2;
					difx33 += ri*x33k[ilr*nk+ik]*rj;
					ri_2 = ri_1; ri_1 = ri;
					rj_2 = rj_1; rj_1 = rj;
					ri = cr_1[ik+1]*mui*ri_1 - cr_2[ik+1]*ri_2;
					rj = cr_1[ik+1]*muj*rj_1 - cr_2[ik+1]*rj_2;
					sumx33 += ri*x33k[ilr*nk+ik+1]*rj;
					ri_2 = ri_1; ri_1 = ri;
					rj_2 = rj_1; rj_1 = rj;
				} // for ik
				apb[(3*jg+2)*ng3+3*ig] = -imui*difx31*wj;
				apb[(3*jg+2)*ng3+3*ig+1] = -imui*difx32*wj;
				if (ig == jg) apb[(3*jg+2)*ng3+3*ig+2] = imui*(0.5 - difx33*wj);
				else apb[(3*jg+2)*ng3+3*ig+2] = -imui*difx33*wj;
				amb[(3*jg+2)*ng3+3*ig] = -imui*sumx31*wj;
				amb[(3*jg+2)*ng3+3*ig+1] = -imui*sumx32*wj;
				if (ig == jg) amb[(3*jg+2)*ng3+3*ig+2] = imui*(0.5 - sumx33*wj);
				else amb[(3*jg+2)*ng3+3*ig+2] = -imui*sumx33*wj;
			} // for ig
		}//for jg
//
		gsl_matrix_view gsl_apb = gsl_matrix_view_array(apb, ng3, ng3); // move from ilr-loop ?
		gsl_matrix_view gsl_amb = gsl_matrix_view_array(amb, ng3, ng3); // move from ilr-loop ?
		gsl_matrix_view gsl_ab = gsl_matrix_view_array(ab, ng3, ng3);   // move from ilr-loop ?
		gsl_blas_dgemm (CblasNoTrans, CblasNoTrans, 1.0, &gsl_apb.matrix, &gsl_amb.matrix, 0.0, &gsl_ab.matrix);
//
		gsl_vector_complex *gsl_eval = gsl_vector_complex_alloc(ng3);        // move from ilr-loop ?
		gsl_matrix_complex *gsl_evec = gsl_matrix_complex_alloc(ng3, ng3);   // move from ilr-loop ?
		gsl_eigen_nonsymmv_workspace *gsl_w = gsl_eigen_nonsymmv_alloc(ng3); // move from ilr-loop ?
		gsl_eigen_nonsymmv(&gsl_ab.matrix, gsl_eval, gsl_evec, gsl_w);       //							ab is replaced!
		gsl_eigen_nonsymmv_free(gsl_w);                                      // move from ilr-loop ?
//
		for (ig = 0; ig < ng3; ig++) {
			gsl_complex gsl_eval_i = gsl_vector_complex_get (gsl_eval, ig);
			evali = sqrt(GSL_REAL(gsl_eval_i));
			eval[ig] = 2.0*evali;	                                         // we skip 2 in the system matrix B; ...
			eti = exp(-2.0*evali*tau[ilr]);                                  // ... the eigenvalues must be scaled back
			gsl_vector_complex_view evec_i = gsl_matrix_complex_column(gsl_evec, ig);
			for (jg = 0; jg < ng3; jg++) {
				gsl_complex z = gsl_vector_complex_get(&evec_i.vector, jg);
				umu[jg] = GSL_REAL(z);
			} // for jg
			gsl_vector_view gsl_umu = gsl_vector_view_array(umu, ng3);
			gsl_vector_view gsl_abu = gsl_vector_view_array(abu, ng3);
			gsl_blas_dgemv(CblasNoTrans, 1.0, &gsl_amb.matrix, &gsl_umu.vector, 0.0, &gsl_abu.vector);
			for (jg = 0; jg < ng3; jg++) {//skip -0.5 in U and -1/0.5 in U^-1
				u1[ng3*ig+jg] = abu[jg]/evali - umu[jg];
				eu1[ng3*ig+jg] = eti*u1[ng3*ig+jg];
				u2[ng3*ig+jg] = abu[jg]/evali + umu[jg];
				eu2[ng3*ig+jg] = eti*u2[ng3*ig+jg];
			} // for jg
		} // for ig
		gsl_vector_complex_free(gsl_eval); // move from ilr-loop ?
		gsl_matrix_complex_free(gsl_evec); // move from ilr-loop ?
//
		for (imu0 = 0; imu0 < nmu0; imu0++) {
			cs0 = mu0[imu0];
			e0 = exp(-taui/cs0);
			eb = exp(-taue/cs0);
			for (ig = 0; ig < ng1; ig++) {
				mun = -mug[ig];
				mup = mug[ig];
//
				qn_2 = mun; qn_1 = 1.5*mun*mun - 0.5;
				rn_2 = 0.0; rn_1 = C22*(1.0 - mun*mun); // Qk2(x)=3/(2*sqrt(6))*(1-x2)
				qp_2 = mup; qp_1 = 1.5*mup*mup - 0.5;
				rp_2 = 0.0; rp_1 = C22*(1.0 - mup*mup); // Qk2(x)=3/(2*sqrt(6))*(1-x2)
//
				q0_2 = mu0[imu0]; q0_1 = 1.5*mu0[imu0]*mu0[imu0] - 0.5;
//
				fn[3*ig] = x11k[ilr*nk] + qn_2*x11k[ilr*nk+1]*q0_2 + qn_1*x11k[ilr*nk+2]*q0_1;
				fn[3*ig+1] = -rn_1*x12k[ilr*nk+2]*q0_1;
				fn[3*ig+2] = 0.0;
//
				fp[3*ig] = x11k[ilr*nk] + qp_2*x11k[ilr*nk+1]*q0_2 + qp_1*x11k[ilr*nk+2]*q0_1;
				fp[3*ig+1] = -rp_1*x12k[ilr*nk+2]*q0_1;
				fp[3*ig+2] = 0.0;
//
				for (ik = 3; ik < nk; ik++) {
					q0 = cq_1[ik]*cs0*q0_1 - cq_2[ik]*q0_2;
//
					qn = cq_1[ik]*mun*qn_1 - cq_2[ik]*qn_2;
					rn = cr_1[ik]*mun*rn_1 - cr_2[ik]*rn_2;
					fn[3*ig] += qn*x11k[ilr*nk+ik]*q0;
					fn[3*ig+1] += -rn*x12k[ilr*nk+ik]*q0;
					qn_2 = qn_1; qn_1 = qn;
					rn_2 = rn_1; rn_1 = rn;
//
					qp = cq_1[ik]*mup*qp_1 - cq_2[ik]*qp_2;
					rp = cr_1[ik]*mup*rp_1 - cr_2[ik]*rp_2;
					fp[3*ig] += qp*x11k[ilr*nk+ik]*q0;
					fp[3*ig+1] += -rp*x12k[ilr*nk+ik]*q0;
					qp_2 = qp_1; qp_1 = qp;
					rp_2 = rp_1; rp_1 = rp;
//
					q0_2 = q0_1; q0_1 = q0;
				} // for ik
				fn[3*ig] /= mun;
				fn[3*ig+1] /= mun;
				fp[3*ig] /= mup;
				fp[3*ig+1] /= mup;
			} // for ig
//
			for (ig = 0; ig < ng3; ig++) {
				evali = eval[ig];
				f1[ig] = u1[ng3*ig]*fn[0] + u2[ng3*ig]*fp[0];
				f2[ig] = u2[ng3*ig]*fn[0] + u1[ng3*ig]*fp[0];
				for (jg = 1; jg < ng3; jg++) { // for (jg = 0; jg < ng3; jg++) u1[ng3*ig+jg] = ...
					f1[ig] += u1[ng3*ig+jg]*fn[jg] + u2[ng3*ig+jg]*fp[jg];
					f2[ig] += u2[ng3*ig+jg]*fn[jg] + u1[ng3*ig+jg]*fp[jg];
				} // for jg
				neg = (exp(-evali*taui)*e0 - 1.0)*eb/(-evali - 1.0/cs0);
				den = evali - 1.0/cs0;
				if (fabs(den) < TINY)
					pos = taui*e0*eb;
				else
					pos = (e0 - exp(-evali*taui))*eb/den;
				f1[ig] *= pos;
				f2[ig] *= neg;
			} // for ig
//
//			Create and solve Ax=b wrt x: A=[[-eu1 u2]; [-u2 eu1]], b=[f1; f2], x = path radiance
			for (ig = 0; ig < ng3; ig++) {
				b[ig] = f1[ig];
				for (jg = 0; jg < ng3; jg++) A[ig*ng6+jg] = -eu1[ig*ng3+jg];
				for (jg = 0; jg < ng3; jg++) A[ig*ng6+ng3+jg] = u2[ig*ng3+jg];
			} // for ig
			for (ig = 0; ig < ng3; ig++) {
				b[ng3+ig] = f2[ig];
				for (jg = 0; jg < ng3; jg++) A[(ng3+ig)*ng6+jg] = -u2[ig*ng3+jg];
				for (jg = 0; jg < ng3; jg++) A[(ng3+ig)*ng6+ng3+jg] = eu1[ig*ng3+jg];
			} // for ig
//
			gsl_matrix_view gsl_A = gsl_matrix_view_array(A, ng6, ng6);
			gsl_vector_view gsl_b = gsl_vector_view_array(b, ng6);
			gsl_vector_view gsl_x = gsl_vector_view_array(x, ng6);
			gsl_permutation *gsl_p = gsl_permutation_alloc(ng6);
			gsl_linalg_LU_decomp(&gsl_A.matrix, gsl_p, &gsl_s);											// A is replaced !
			gsl_linalg_LU_solve(&gsl_A.matrix, gsl_p, &gsl_b.vector, &gsl_x.vector);
			gsl_permutation_free(gsl_p);
//
			for (ig = 0; ig < ng6; ig++) iqu[imu0*ng1+ig] = x[ig];
		} // for imu0
		taue += tau[ilr]; // embedding of the next boundary
	} // for ilr
//
	delete[] apb;
	delete[] amb;
	delete[] ab;
	delete[] umu;
	delete[] abu;
	delete[] u1;
	delete[] u2;
	delete[] eu1;
	delete[] eu2;
	delete[] eval;
	delete[] fn;
	delete[] fp;
	delete[] f1;
	delete[] f2;
	delete[] x;
	delete[] b;
	delete[] A;
	delete[] mug;
	delete[] wg;
	delete[] cq_1;
	delete[] cq_2;
	delete[] cr_1;
	delete[] cr_2;
} // domm0(...)